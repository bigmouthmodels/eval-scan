# EvalScan Report

---

> [!WARNING]
> EvalScan is a new tool that is being actively developed. It hasn't been comprehensively tested, so you should interpret results cautiously.
Report generated: 2025-05-02 14:05:15 UTC

Source database: /home/ubuntu/los-alamos/cybench-100-t0.db

No. samples: 120

No. models: 3

No. tasks: 40

![](./2bd120b5-62b2-431c-b514-b836d12aee6c.svg)

![](./71f5248d-f8bd-4c95-b06e-d49f2e4213e3.svg)

![](./069f26f5-9d7b-405e-850f-059453edf008.svg)

---

_Compiled in 20 seconds_


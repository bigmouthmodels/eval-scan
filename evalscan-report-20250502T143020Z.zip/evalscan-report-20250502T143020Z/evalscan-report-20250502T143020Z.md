# EvalScan Report (impact-whom-dinner)

---

> [!WARNING]
> EvalScan is a new tool that is being actively developed. It hasn't been comprehensively tested, so you should interpret results cautiously.

Report generated: 2025-05-02 14:05:20 UTC

Source database: /home/ubuntu/los-alamos/cybench-100-t0.db

No. samples: 120

No. models: 3

No. tasks: 40

![](./15f186af-c549-4226-b9be-c4bce793129d.svg)

![](./83205281-2be7-4b58-a824-742c199f0ff4.svg)

![](./c41c5ffa-c018-459e-8cd9-6eec9956366f.svg)

---

_Compiled in 20 seconds_

